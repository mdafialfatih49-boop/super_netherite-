package com.supernetherite;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.passive.HorseEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.DyeColor;

/** Mob hasil fusi: mob vanilla yang diberi nama khusus dan stat jauh lebih kuat. */
public final class FusedMobs {
    private static final int FOREVER = 20 * 60 * 60 * 10;

    @FunctionalInterface
    public interface Spawner {
        void spawn(ServerWorld world, double x, double y, double z, float yaw, PlayerEntity owner);
    }

    private FusedMobs() {
    }

    private static void attr(LivingEntity entity, EntityAttribute attribute, double value) {
        EntityAttributeInstance instance = entity.getAttributeInstance(attribute);
        if (instance != null) {
            instance.setBaseValue(value);
        }
    }

    /** Kuda + Sapi = "Kuda Sapi": kuda jinak berpelana, darah tebal, cepat, dan meregenerasi diri. */
    public static void spawnHorseCow(ServerWorld world, double x, double y, double z, float yaw, PlayerEntity owner) {
        HorseEntity horse = EntityType.HORSE.create(world);
        if (horse == null) {
            return;
        }
        horse.refreshPositionAndAngles(x, y, z, yaw, 0.0f);
        horse.setCustomName(Text.literal("Kuda Sapi"));
        horse.setCustomNameVisible(true);
        attr(horse, EntityAttributes.GENERIC_MAX_HEALTH, 60.0);
        attr(horse, EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.38);
        attr(horse, EntityAttributes.HORSE_JUMP_STRENGTH, 1.0);
        horse.setHealth(60.0f);
        horse.setTame(true);
        if (owner != null) {
            horse.setOwnerUuid(owner.getUuid());
        }
        horse.getInventory().setStack(0, new ItemStack(Items.SADDLE));
        horse.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, FOREVER, 0, false, false));
        world.spawnEntity(horse);
    }

    /** Domba + Ayam = "Domba Ayam": domba kuning yang melayang pelan seperti ayam. */
    public static void spawnSheepChicken(ServerWorld world, double x, double y, double z, float yaw, PlayerEntity owner) {
        SheepEntity sheep = EntityType.SHEEP.create(world);
        if (sheep == null) {
            return;
        }
        sheep.refreshPositionAndAngles(x, y, z, yaw, 0.0f);
        sheep.setCustomName(Text.literal("Domba Ayam"));
        sheep.setCustomNameVisible(true);
        sheep.setColor(DyeColor.YELLOW);
        attr(sheep, EntityAttributes.GENERIC_MAX_HEALTH, 40.0);
        attr(sheep, EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.35);
        sheep.setHealth(40.0f);
        sheep.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, FOREVER, 0, false, false));
        sheep.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, FOREVER, 1, false, false));
        world.spawnEntity(sheep);
    }

    /** Ocelot + Kucing = "Kucing Ocelot": kucing jinak yang cepat dan kuat menyerang. */
    public static void spawnOcelotCat(ServerWorld world, double x, double y, double z, float yaw, PlayerEntity owner) {
        CatEntity cat = EntityType.CAT.create(world);
        if (cat == null) {
            return;
        }
        cat.refreshPositionAndAngles(x, y, z, yaw, 0.0f);
        cat.setCustomName(Text.literal("Kucing Ocelot"));
        cat.setCustomNameVisible(true);
        attr(cat, EntityAttributes.GENERIC_MAX_HEALTH, 30.0);
        attr(cat, EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.42);
        attr(cat, EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0);
        cat.setHealth(30.0f);
        if (owner != null) {
            cat.setOwner(owner);
        } else {
            cat.setTamed(true);
        }
        cat.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, FOREVER, 0, false, false));
        world.spawnEntity(cat);
    }
}
