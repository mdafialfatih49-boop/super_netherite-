package com.supernetherite.mixin;

import com.supernetherite.FusionManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PistonBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PistonBlock.class)
public class PistonBlockMixin {
    @Inject(method = "onSyncedBlockEvent", at = @At("RETURN"))
    private void supernetherite$afterEvent(BlockState state, World world, BlockPos pos, int type, int data,
                                           CallbackInfoReturnable<Boolean> cir) {
        // type 0 = piston mulai memanjang (extend)
        if (type == 0 && cir.getReturnValueZ() && world instanceof ServerWorld serverWorld
                && state.isOf(Blocks.STICKY_PISTON)) {
            FusionManager.schedule(serverWorld, pos, state.get(Properties.FACING));
        }
    }
}
