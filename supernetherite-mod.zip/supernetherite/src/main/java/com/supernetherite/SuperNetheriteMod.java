package com.supernetherite;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class SuperNetheriteMod implements ModInitializer {
    public static final String MOD_ID = "supernetherite";

    public static final Block SUPER_NETHERITE_BLOCK = new Block(
            FabricBlockSettings.copyOf(Blocks.NETHERITE_BLOCK).strength(80.0f, 2000.0f));

    public static final BlockItem SUPER_NETHERITE_ITEM = new BlockItem(
            SUPER_NETHERITE_BLOCK, new FabricItemSettings().fireproof());

    @Override
    public void onInitialize() {
        Identifier id = new Identifier(MOD_ID, "super_netherite_block");
        Registry.register(Registries.BLOCK, id, SUPER_NETHERITE_BLOCK);
        Registry.register(Registries.ITEM, id, SUPER_NETHERITE_ITEM);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS)
                .register(entries -> entries.add(SUPER_NETHERITE_ITEM));

        ServerTickEvents.END_SERVER_TICK.register(FusionManager::tick);
    }
}
